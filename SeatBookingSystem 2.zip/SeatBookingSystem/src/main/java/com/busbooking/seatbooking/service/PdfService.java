package com.busbooking.seatbooking.service;

import com.busbooking.seatbooking.model.Booking;
import com.busbooking.seatbooking.model.Ticket;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;

@Service
public class PdfService {

    public byte[] generateTicketPdf(Booking booking, Ticket ticket) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            PdfWriter writer = new PdfWriter(outputStream);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);
            
            // Add title
            Paragraph title = new Paragraph("LankaGoExpress - Bus Ticket")
                    .setTextAlignment(TextAlignment.CENTER)
                    .setFontSize(20)
                    .setBold();
            document.add(title);
            
            // Add ticket number
            Paragraph ticketNumber = new Paragraph("Ticket #" + ticket.getTicketNumber())
                    .setTextAlignment(TextAlignment.CENTER)
                    .setFontSize(16)
                    .setBold();
            document.add(ticketNumber);
            
            // Add spacing
            document.add(new Paragraph("\n"));
            
            // Create table for ticket details
            Table table = new Table(2).useAllAvailableWidth();
            
            // Passenger Details
            table.addCell(new Cell().add(new Paragraph("Passenger Details").setBold()));
            table.addCell(new Cell().add(new Paragraph("Journey Details").setBold()));
            
            table.addCell(new Cell().add(new Paragraph("Name: " + booking.getPassengerName())));
            table.addCell(new Cell().add(new Paragraph("Route: " + booking.getOrigin() + " → " + booking.getDestination())));
            
            table.addCell(new Cell().add(new Paragraph("Email: " + booking.getEmail())));
            table.addCell(new Cell().add(new Paragraph("Bus: " + booking.getBusNumber())));
            
            table.addCell(new Cell().add(new Paragraph("Phone: " + booking.getPhone())));
            table.addCell(new Cell().add(new Paragraph("Seat: " + booking.getSeatNumber())));
            
            table.addCell(new Cell().add(new Paragraph("Booking ID: " + booking.getId())));
            table.addCell(new Cell().add(new Paragraph("Price: $" + booking.getTicketPrice())));
            
            document.add(table);
            
            // Add ticket information
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("Ticket Information").setBold());
            document.add(new Paragraph("Status: " + ticket.getStatus()));
            document.add(new Paragraph("Issued: " + ticket.getIssuedTime().format(DateTimeFormatter.ofPattern("dd MMM yyyy 'at' HH:mm"))));
            document.add(new Paragraph("Expires: " + ticket.getExpiryTime().format(DateTimeFormatter.ofPattern("dd MMM yyyy 'at' HH:mm"))));
            document.add(new Paragraph("QR Code: " + ticket.getQrCode()));
            
            // Add footer
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("Important: Please arrive 15 minutes before departure time.").setItalic());
            document.add(new Paragraph("Present this ticket (digital or printed) to the driver.").setItalic());
            document.add(new Paragraph("For support, contact: support@lankagoexpress.com").setItalic());
            
            document.close();
            return outputStream.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate PDF: " + e.getMessage(), e);
        }
    }

}
