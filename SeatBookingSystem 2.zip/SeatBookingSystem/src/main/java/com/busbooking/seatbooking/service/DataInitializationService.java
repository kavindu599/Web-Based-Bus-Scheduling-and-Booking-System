package com.busbooking.seatbooking.service;

import com.busbooking.seatbooking.model.Booking;
import com.busbooking.seatbooking.model.Payment;
import com.busbooking.seatbooking.repository.BookingRepository;
import com.busbooking.seatbooking.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class DataInitializationService implements CommandLineRunner {

    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public void run(String... args) throws Exception {
        // Always create sample data for testing
        System.out.println("Creating sample data...");
        try {
            createSampleData();
            System.out.println("Sample data created successfully!");
        } catch (Exception e) {
            System.err.println("Error creating sample data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void createSampleData() {
        // Sample booking 1
        Booking booking1 = new Booking();
        booking1.setPassengerName("John Smith");
        booking1.setEmail("john.smith@email.com");
        booking1.setPhone("1234567890");
        booking1.setOrigin("New York");
        booking1.setDestination("Boston");
        booking1.setBusNumber("BUS-001");
        booking1.setSeatNumber(1);
        booking1.setTicketPrice(45.00);
        booking1.setStatus("CONFIRMED");
        booking1.setBookingTime(LocalDateTime.now().minusHours(2));
        booking1 = bookingRepository.save(booking1);

        // Sample booking 2
        Booking booking2 = new Booking();
        booking2.setPassengerName("Sarah Johnson");
        booking2.setEmail("sarah.j@email.com");
        booking2.setPhone("2345678901");
        booking2.setOrigin("Boston");
        booking2.setDestination("Philadelphia");
        booking2.setBusNumber("BUS-002");
        booking2.setSeatNumber(3);
        booking2.setTicketPrice(65.00);
        booking2.setStatus("APPROVED");
        booking2.setBookingTime(LocalDateTime.now().minusHours(1));
        booking2 = bookingRepository.save(booking2);

        // Sample booking 3
        Booking booking3 = new Booking();
        booking3.setPassengerName("Mike Wilson");
        booking3.setEmail("mike.w@email.com");
        booking3.setPhone("3456789012");
        booking3.setOrigin("Philadelphia");
        booking3.setDestination("Washington DC");
        booking3.setBusNumber("BUS-003");
        booking3.setSeatNumber(5);
        booking3.setTicketPrice(55.00);
        booking3.setStatus("CONFIRMED");
        booking3.setBookingTime(LocalDateTime.now().minusMinutes(30));
        booking3 = bookingRepository.save(booking3);

        // Create payments for bookings
        createPayment(booking1, "CASH", "COMPLETED");
        createPayment(booking2, "CREDIT_CARD", "COMPLETED");
        createPayment(booking3, "DEBIT_CARD", "PENDING");

        // Note: Tickets are now automatically created when bookings are saved
        // No need to manually create tickets here
    }

    private void createPayment(Booking booking, String method, String status) {
        Payment payment = new Payment();
        payment.setBookingId(booking.getId());
        payment.setAmount(booking.getTicketPrice());
        payment.setPaymentMethod(method);
        payment.setStatus(status);
        payment.setTransactionId("TXN-" + System.currentTimeMillis());
        payment.setReferenceNumber("REF-" + (1000 + new Random().nextInt(9000)));
        payment.setPaymentTime(LocalDateTime.now().minusMinutes(new Random().nextInt(60)));
        
        if ("COMPLETED".equals(status)) {
            payment.setProcessedTime(LocalDateTime.now().minusMinutes(new Random().nextInt(30)));
        }
        
        paymentRepository.save(payment);
    }

}
