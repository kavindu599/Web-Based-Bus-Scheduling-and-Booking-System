package com.busbooking.seatbooking.controller;

import com.busbooking.seatbooking.dto.*;
import com.busbooking.seatbooking.model.Booking;
import com.busbooking.seatbooking.model.Payment;
import com.busbooking.seatbooking.model.Ticket;
import com.busbooking.seatbooking.service.BookingService;
import com.busbooking.seatbooking.service.PdfService;
import com.busbooking.seatbooking.service.TicketingService;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/ticketing-clerk")
public class TicketingClerkController {

    private final TicketingService ticketingService;
    private final BookingService bookingService;
    private final PdfService pdfService;

    public TicketingClerkController(TicketingService ticketingService, BookingService bookingService, PdfService pdfService) {
        this.ticketingService = ticketingService;
        this.bookingService = bookingService;
        this.pdfService = pdfService;
    }

    // Login page for ticketing clerk
    @GetMapping("/login")
    public String loginPage(Model model) {
        model.addAttribute("clerkName", "");
        return "ticketing-clerk/login";
    }

    // Process login
    @PostMapping("/login")
    public String processLogin(@RequestParam("clerkName") String clerkName, Model model) {
        if (clerkName == null || clerkName.trim().isEmpty()) {
            model.addAttribute("error", "Please enter your name");
            return "ticketing-clerk/login";
        }
        
        model.addAttribute("clerkName", clerkName.trim());
        return "redirect:/ticketing-clerk/dashboard?clerkName=" + clerkName.trim();
    }

    // Dashboard - Select function
    @GetMapping("/dashboard")
    public String dashboard(@RequestParam("clerkName") String clerkName, Model model) {
        model.addAttribute("clerkName", clerkName);
        return "ticketing-clerk/dashboard";
    }

    // UC-10: Process Payment - Form
    @GetMapping("/process-payment")
    public String processPaymentForm(@RequestParam("clerkName") String clerkName, Model model) {
        model.addAttribute("clerkName", clerkName);
        model.addAttribute("paymentRequest", new PaymentRequest());
        return "ticketing-clerk/process-payment";
    }

    // UC-10: Process Payment - Submit
    @PostMapping("/process-payment")
    public String processPaymentSubmit(@RequestParam("clerkName") String clerkName,
                                     @Valid @ModelAttribute PaymentRequest paymentRequest,
                                     BindingResult result, Model model) {
        model.addAttribute("clerkName", clerkName);

        if (result.hasErrors()) {
            return "ticketing-clerk/process-payment";
        }

        try {
            Payment payment = ticketingService.processPayment(paymentRequest);
            Booking booking = bookingService.getBookingById(paymentRequest.getBookingId());
            
            model.addAttribute("success", "Payment processed successfully!");
            model.addAttribute("payment", payment);
            model.addAttribute("booking", booking);
            model.addAttribute("ticket", ticketingService.getTicketsByBookingId(paymentRequest.getBookingId()).get(0));
            
            return "ticketing-clerk/payment-success";
        } catch (Exception e) {
            model.addAttribute("error", "Payment failed: " + e.getMessage());
            return "ticketing-clerk/process-payment";
        }
    }

    // UC-11: Verify Ticket - Form
    @GetMapping("/verify-ticket")
    public String verifyTicketForm(@RequestParam("clerkName") String clerkName, Model model) {
        model.addAttribute("clerkName", clerkName);
        model.addAttribute("verificationRequest", new TicketVerificationRequest());
        return "ticketing-clerk/verify-ticket";
    }

    // UC-11: Verify Ticket - Submit
    @PostMapping("/verify-ticket")
    public String verifyTicketSubmit(@RequestParam("clerkName") String clerkName,
                                   @Valid @ModelAttribute TicketVerificationRequest verificationRequest,
                                   BindingResult result, Model model) {
        model.addAttribute("clerkName", clerkName);

        if (result.hasErrors()) {
            return "ticketing-clerk/verify-ticket";
        }

        try {
            verificationRequest.setClerkName(clerkName);
            TicketVerificationResponse response = ticketingService.verifyTicket(verificationRequest);
            
            model.addAttribute("response", response);
            
            if (response.isValid()) {
                model.addAttribute("success", response.getMessage());
            } else {
                model.addAttribute("error", response.getMessage());
            }
            
            return "ticketing-clerk/verification-result";
        } catch (Exception e) {
            model.addAttribute("error", "Verification failed: " + e.getMessage());
            return "ticketing-clerk/verify-ticket";
        }
    }

    // Generate Passenger Manifest
    @GetMapping("/passenger-manifest")
    public String passengerManifest(@RequestParam("clerkName") String clerkName,
                                  @RequestParam(value = "busNumber", required = false) String busNumber,
                                  Model model) {
        model.addAttribute("clerkName", clerkName);
        
        if (busNumber != null && !busNumber.trim().isEmpty()) {
            PassengerManifest manifest = ticketingService.generatePassengerManifest(busNumber);
            model.addAttribute("manifest", manifest);
        }
        
        return "ticketing-clerk/passenger-manifest";
    }

    // Booking lookup for payment processing
    @GetMapping("/lookup-booking")
    public String lookupBooking(@RequestParam("clerkName") String clerkName,
                              @RequestParam(value = "bookingId", required = false) Long bookingId,
                              Model model) {
        model.addAttribute("clerkName", clerkName);
        
        if (bookingId != null) {
            try {
                Booking booking = bookingService.getBookingById(bookingId);
                if (booking != null) {
                    List<Payment> payments = ticketingService.getPaymentsByBookingId(bookingId);
                    List<Ticket> tickets = ticketingService.getTicketsByBookingId(bookingId);
                    
                    model.addAttribute("booking", booking);
                    model.addAttribute("payments", payments != null ? payments : new ArrayList<>());
                    model.addAttribute("tickets", tickets != null ? tickets : new ArrayList<>());
                } else {
                    model.addAttribute("error", "Booking not found with ID: " + bookingId);
                }
            } catch (Exception e) {
                model.addAttribute("error", "Error retrieving booking: " + e.getMessage());
            }
        }
        
        return "ticketing-clerk/lookup-booking";
    }

    // REST API endpoints for AJAX calls
    @GetMapping("/api/booking/{bookingId}")
    @ResponseBody
    public ResponseEntity<Booking> getBooking(@PathVariable Long bookingId) {
        try {
            Booking booking = bookingService.getBookingById(bookingId);
            return ResponseEntity.ok(booking);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/api/ticket/{ticketNumber}")
    @ResponseBody
    public ResponseEntity<TicketVerificationResponse> getTicketInfo(@PathVariable String ticketNumber) {
        try {
            Optional<Ticket> ticketOpt = ticketingService.getTicketByNumber(ticketNumber);
            if (ticketOpt.isPresent()) {
                Ticket ticket = ticketOpt.get();
                Booking booking = bookingService.getBookingById(ticket.getBookingId());
                
                TicketVerificationResponse response = new TicketVerificationResponse(
                    true, "Ticket found", ticket, booking, "PENDING"
                );
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/api/statistics/{busNumber}")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getStatistics(@PathVariable String busNumber) {
        Map<String, Object> stats = ticketingService.getBookingStatistics(busNumber);
        return ResponseEntity.ok(stats);
    }

    // PDF Ticket Download
    @GetMapping("/download-ticket")
    public ResponseEntity<byte[]> downloadTicket(@RequestParam("clerkName") String clerkName,
                                               @RequestParam("bookingId") Long bookingId) {
        try {
            Booking booking = bookingService.getBookingById(bookingId);
            if (booking == null) {
                return ResponseEntity.notFound().build();
            }

            List<Ticket> tickets = ticketingService.getTicketsByBookingId(bookingId);
            if (tickets == null || tickets.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            // Use the first ticket for PDF generation
            Ticket ticket = tickets.get(0);
            byte[] pdfBytes = pdfService.generateTicketPdf(booking, ticket);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", 
                "ticket_" + ticket.getTicketNumber() + ".pdf");
            headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(pdfBytes);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
