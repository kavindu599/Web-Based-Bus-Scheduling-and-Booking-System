package com.busbooking.seatbooking.dto;

import jakarta.validation.constraints.NotBlank;

public class TicketVerificationRequest {

    @NotBlank(message = "Ticket identifier is required")
    private String ticketIdentifier; // Can be ticket number or QR code

    private String clerkName;

    // ---------------- Getters & Setters ----------------
    public String getTicketIdentifier() { return ticketIdentifier; }
    public void setTicketIdentifier(String ticketIdentifier) { this.ticketIdentifier = ticketIdentifier; }

    public String getClerkName() { return clerkName; }
    public void setClerkName(String clerkName) { this.clerkName = clerkName; }
}
