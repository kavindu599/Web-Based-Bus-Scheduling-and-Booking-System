package com.busbooking.seatbooking.dto;

import com.busbooking.seatbooking.model.Booking;
import com.busbooking.seatbooking.model.Ticket;

public class TicketVerificationResponse {
    
    private boolean valid;
    private String message;
    private Ticket ticket;
    private Booking booking;
    private String passengerStatus; // BOARDED, PENDING, EXPIRED, INVALID

    public TicketVerificationResponse() {}

    public TicketVerificationResponse(boolean valid, String message, Ticket ticket, Booking booking, String passengerStatus) {
        this.valid = valid;
        this.message = message;
        this.ticket = ticket;
        this.booking = booking;
        this.passengerStatus = passengerStatus;
    }

    // ---------------- Getters & Setters ----------------
    public boolean isValid() { return valid; }
    public void setValid(boolean valid) { this.valid = valid; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) { this.ticket = ticket; }

    public Booking getBooking() { return booking; }
    public void setBooking(Booking booking) { this.booking = booking; }

    public String getPassengerStatus() { return passengerStatus; }
    public void setPassengerStatus(String passengerStatus) { this.passengerStatus = passengerStatus; }
}
