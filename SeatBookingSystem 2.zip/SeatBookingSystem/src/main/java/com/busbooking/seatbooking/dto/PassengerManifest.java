package com.busbooking.seatbooking.dto;

import com.busbooking.seatbooking.model.Booking;
import java.time.LocalDateTime;
import java.util.List;

public class PassengerManifest {
    
    private String busNumber;
    private String route;
    private LocalDateTime generatedAt;
    private int totalPassengers;
    private int boardedPassengers;
    private int pendingPassengers;
    private List<PassengerInfo> passengers;

    public PassengerManifest() {}

    public PassengerManifest(String busNumber, String route, LocalDateTime generatedAt, 
                           int totalPassengers, int boardedPassengers, int pendingPassengers, 
                           List<PassengerInfo> passengers) {
        this.busNumber = busNumber;
        this.route = route;
        this.generatedAt = generatedAt;
        this.totalPassengers = totalPassengers;
        this.boardedPassengers = boardedPassengers;
        this.pendingPassengers = pendingPassengers;
        this.passengers = passengers;
    }

    // ---------------- Getters & Setters ----------------
    public String getBusNumber() { return busNumber; }
    public void setBusNumber(String busNumber) { this.busNumber = busNumber; }

    public String getRoute() { return route; }
    public void setRoute(String route) { this.route = route; }

    public LocalDateTime getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(LocalDateTime generatedAt) { this.generatedAt = generatedAt; }

    public int getTotalPassengers() { return totalPassengers; }
    public void setTotalPassengers(int totalPassengers) { this.totalPassengers = totalPassengers; }

    public int getBoardedPassengers() { return boardedPassengers; }
    public void setBoardedPassengers(int boardedPassengers) { this.boardedPassengers = boardedPassengers; }

    public int getPendingPassengers() { return pendingPassengers; }
    public void setPendingPassengers(int pendingPassengers) { this.pendingPassengers = pendingPassengers; }

    public List<PassengerInfo> getPassengers() { return passengers; }
    public void setPassengers(List<PassengerInfo> passengers) { this.passengers = passengers; }

    // Inner class for passenger information
    public static class PassengerInfo {
        private Long bookingId;
        private String passengerName;
        private String phone;
        private String email;
        private Integer seatNumber;
        private String status; // BOARDED, PENDING, EXPIRED
        private LocalDateTime bookingTime;
        private LocalDateTime boardedTime;

        public PassengerInfo() {}

        public PassengerInfo(Long bookingId, String passengerName, String phone, String email, 
                           Integer seatNumber, String status, LocalDateTime bookingTime, LocalDateTime boardedTime) {
            this.bookingId = bookingId;
            this.passengerName = passengerName;
            this.phone = phone;
            this.email = email;
            this.seatNumber = seatNumber;
            this.status = status;
            this.bookingTime = bookingTime;
            this.boardedTime = boardedTime;
        }

        // Getters and Setters
        public Long getBookingId() { return bookingId; }
        public void setBookingId(Long bookingId) { this.bookingId = bookingId; }

        public String getPassengerName() { return passengerName; }
        public void setPassengerName(String passengerName) { this.passengerName = passengerName; }

        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }

        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }

        public Integer getSeatNumber() { return seatNumber; }
        public void setSeatNumber(Integer seatNumber) { this.seatNumber = seatNumber; }

        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }

        public LocalDateTime getBookingTime() { return bookingTime; }
        public void setBookingTime(LocalDateTime bookingTime) { this.bookingTime = bookingTime; }

        public LocalDateTime getBoardedTime() { return boardedTime; }
        public void setBoardedTime(LocalDateTime boardedTime) { this.boardedTime = boardedTime; }
    }
}
