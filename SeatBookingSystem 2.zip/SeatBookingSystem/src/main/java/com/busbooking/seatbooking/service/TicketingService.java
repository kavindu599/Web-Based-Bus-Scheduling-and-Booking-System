package com.busbooking.seatbooking.service;

import com.busbooking.seatbooking.dto.*;
import com.busbooking.seatbooking.exception.BookingNotFoundException;
import com.busbooking.seatbooking.model.*;
import com.busbooking.seatbooking.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TicketingService {

    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final TicketRepository ticketRepository;

    public TicketingService(BookingRepository bookingRepository, PaymentRepository paymentRepository, 
                           TicketRepository ticketRepository) {
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
        this.ticketRepository = ticketRepository;
    }

    // UC-10: Process Payments
    @Transactional
    public Payment processPayment(PaymentRequest paymentRequest) {
        // Validate booking exists
        Booking booking = bookingRepository.findById(paymentRequest.getBookingId())
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        // Check if payment already exists for this booking
        List<Payment> existingPayments = paymentRepository.findByBookingId(paymentRequest.getBookingId());
        if (!existingPayments.isEmpty()) {
            Payment existingPayment = existingPayments.get(0);
            if ("COMPLETED".equals(existingPayment.getStatus())) {
                throw new IllegalArgumentException("Payment already completed for this booking");
            }
        }

        // Create payment record
        Payment payment = new Payment();
        payment.setBookingId(paymentRequest.getBookingId());
        payment.setAmount(paymentRequest.getAmount());
        payment.setPaymentMethod(paymentRequest.getPaymentMethod());
        payment.setTransactionId(paymentRequest.getTransactionId());
        payment.setReferenceNumber(paymentRequest.getReferenceNumber());
        payment.setNotes(paymentRequest.getNotes());
        payment.setStatus("PENDING");

        // Simulate payment processing
        try {
            // In a real system, this would integrate with payment gateway
            Thread.sleep(1000); // Simulate processing time
            
            // Simulate 95% success rate
            if (Math.random() > 0.05) {
                payment.setStatus("COMPLETED");
                payment.setProcessedTime(LocalDateTime.now());
                
                // Generate ticket after successful payment
                generateTicket(booking);
            } else {
                payment.setStatus("FAILED");
                throw new RuntimeException("Payment processing failed. Please try again or use a different payment method.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            payment.setStatus("FAILED");
            throw new RuntimeException("Payment processing interrupted");
        }

        return paymentRepository.save(payment);
    }

    // Generate ticket after successful payment
    @Transactional
    public Ticket generateTicket(Booking booking) {
        // Check if ticket already exists
        List<Ticket> existingTickets = ticketRepository.findByBookingId(booking.getId());
        if (!existingTickets.isEmpty()) {
            return existingTickets.get(0);
        }

        Ticket ticket = new Ticket();
        ticket.setBookingId(booking.getId());
        ticket.setTicketNumber(generateTicketNumber());
        ticket.setQrCode(generateQRCode(booking));
        ticket.setStatus("ISSUED");
        ticket.setExpiryTime(LocalDateTime.now().plusHours(24));

        return ticketRepository.save(ticket);
    }

    // UC-11: Verify Tickets
    @Transactional
    public TicketVerificationResponse verifyTicket(TicketVerificationRequest request) {
        String ticketIdentifier = request.getTicketIdentifier().trim();
        String clerkName = request.getClerkName();

        Optional<Ticket> ticketOpt;
        try {
            // Find ticket by ticket number or QR code
            ticketOpt = ticketRepository.findByTicketNumber(ticketIdentifier);
            if (ticketOpt.isEmpty()) {
                ticketOpt = ticketRepository.findByQrCode(ticketIdentifier);
            }

            if (ticketOpt.isEmpty()) {
                return new TicketVerificationResponse(false, "Ticket not found", null, null, "INVALID");
            }
        } catch (Exception e) {
            // Handle case when database tables don't exist yet
            TicketVerificationResponse response = new TicketVerificationResponse();
            response.setValid(false);
            response.setMessage("Database not initialized. No tickets available.");
            response.setPassengerStatus("ERROR");
            return response;
        }

        Ticket ticket = ticketOpt.get();
        Booking booking = bookingRepository.findById(ticket.getBookingId())
                .orElseThrow(() -> new BookingNotFoundException("Booking not found"));

        // Check if ticket is expired
        if (ticket.getExpiryTime().isBefore(LocalDateTime.now())) {
            ticket.setStatus("EXPIRED");
            ticketRepository.save(ticket);
            return new TicketVerificationResponse(false, "Ticket has expired", ticket, booking, "EXPIRED");
        }

        // Check if ticket is already used
        if ("USED".equals(ticket.getStatus())) {
            return new TicketVerificationResponse(false, "Ticket has already been used", ticket, booking, "USED");
        }

        // Check if ticket is cancelled
        if ("CANCELLED".equals(ticket.getStatus())) {
            return new TicketVerificationResponse(false, "Ticket has been cancelled", ticket, booking, "CANCELLED");
        }

        // Verify ticket
        ticket.setStatus("VERIFIED");
        ticket.setVerifiedTime(LocalDateTime.now());
        ticket.setVerifiedBy(clerkName);
        ticketRepository.save(ticket);

        // Update passenger status to boarded
        booking.setStatus("BOARDED");
        bookingRepository.save(booking);

        return new TicketVerificationResponse(true, "Ticket verified successfully. Passenger can board.", 
                                            ticket, booking, "BOARDED");
    }

    // Generate passenger manifest
    public PassengerManifest generatePassengerManifest(String busNumber) {
        List<Booking> bookings = bookingRepository.findAll().stream()
                .filter(booking -> busNumber.equals(booking.getBusNumber()))
                .collect(Collectors.toList());

        List<PassengerManifest.PassengerInfo> passengers = bookings.stream()
                .map(booking -> {
                    String status = "BOARDED".equals(booking.getStatus()) ? "BOARDED" : "PENDING";
                    LocalDateTime boardedTime = "BOARDED".equals(booking.getStatus()) ? 
                            LocalDateTime.now() : null;
                    
                    return new PassengerManifest.PassengerInfo(
                            booking.getId(),
                            booking.getPassengerName(),
                            booking.getPhone(),
                            booking.getEmail(),
                            booking.getSeatNumber(),
                            status,
                            booking.getBookingTime(),
                            boardedTime
                    );
                })
                .collect(Collectors.toList());

        int totalPassengers = passengers.size();
        int boardedPassengers = (int) passengers.stream()
                .filter(p -> "BOARDED".equals(p.getStatus()))
                .count();
        int pendingPassengers = totalPassengers - boardedPassengers;

        String route = bookings.isEmpty() ? "No bookings" : 
                bookings.get(0).getOrigin() + " → " + bookings.get(0).getDestination();

        return new PassengerManifest(
                busNumber,
                route,
                LocalDateTime.now(),
                totalPassengers,
                boardedPassengers,
                pendingPassengers,
                passengers
        );
    }

    // Get all payments for a booking
    public List<Payment> getPaymentsByBookingId(Long bookingId) {
        return paymentRepository.findByBookingId(bookingId);
    }

    // Get all tickets for a booking
    public List<Ticket> getTicketsByBookingId(Long bookingId) {
        return ticketRepository.findByBookingId(bookingId);
    }

    // Get ticket by ticket number
    public Optional<Ticket> getTicketByNumber(String ticketNumber) {
        return ticketRepository.findByTicketNumber(ticketNumber);
    }

    // Get ticket by QR code
    public Optional<Ticket> getTicketByQRCode(String qrCode) {
        return ticketRepository.findByQrCode(qrCode);
    }

    // Helper methods
    private String generateTicketNumber() {
        return "TKT" + System.currentTimeMillis() + (int)(Math.random() * 1000);
    }

    private String generateQRCode(Booking booking) {
        // In a real system, this would generate an actual QR code
        return "QR" + booking.getId() + "_" + booking.getSeatNumber() + "_" + 
               booking.getBusNumber() + "_" + System.currentTimeMillis();
    }

    // Get all bookings for a specific bus
    public List<Booking> getBookingsByBusNumber(String busNumber) {
        return bookingRepository.findAll().stream()
                .filter(booking -> busNumber.equals(booking.getBusNumber()))
                .collect(Collectors.toList());
    }

    // Get booking statistics
    public Map<String, Object> getBookingStatistics(String busNumber) {
        List<Booking> bookings = getBookingsByBusNumber(busNumber);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalBookings", bookings.size());
        stats.put("confirmedBookings", bookings.stream()
                .filter(b -> "CONFIRMED".equals(b.getStatus())).count());
        stats.put("boardedPassengers", bookings.stream()
                .filter(b -> "BOARDED".equals(b.getStatus())).count());
        stats.put("totalRevenue", bookings.stream()
                .mapToDouble(Booking::getTicketPrice)
                .sum());
        
        return stats;
    }
}
