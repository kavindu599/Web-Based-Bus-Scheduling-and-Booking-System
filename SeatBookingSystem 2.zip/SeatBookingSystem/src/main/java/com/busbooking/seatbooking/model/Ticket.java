package com.busbooking.seatbooking.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "tickets")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Booking ID is required")
    private Long bookingId;

    @NotBlank(message = "Ticket number is required")
    private String ticketNumber;

    @NotBlank(message = "QR code is required")
    private String qrCode;

    @NotBlank(message = "Status is required")
    private String status; // ISSUED, VERIFIED, USED, EXPIRED, CANCELLED

    private LocalDateTime issuedTime;
    private LocalDateTime verifiedTime;
    private LocalDateTime usedTime;
    private LocalDateTime expiryTime;

    private String verifiedBy; // Clerk name who verified
    private String notes;

    @PrePersist
    public void onCreate() {
        issuedTime = LocalDateTime.now();
        if (status == null) {
            status = "ISSUED";
        }
        if (expiryTime == null) {
            // Ticket expires 24 hours after issue
            expiryTime = LocalDateTime.now().plusHours(24);
        }
    }

    // ---------------- Getters & Setters ----------------
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getBookingId() { return bookingId; }
    public void setBookingId(Long bookingId) { this.bookingId = bookingId; }

    public String getTicketNumber() { return ticketNumber; }
    public void setTicketNumber(String ticketNumber) { this.ticketNumber = ticketNumber; }

    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getIssuedTime() { return issuedTime; }
    public void setIssuedTime(LocalDateTime issuedTime) { this.issuedTime = issuedTime; }

    public LocalDateTime getVerifiedTime() { return verifiedTime; }
    public void setVerifiedTime(LocalDateTime verifiedTime) { this.verifiedTime = verifiedTime; }

    public LocalDateTime getUsedTime() { return usedTime; }
    public void setUsedTime(LocalDateTime usedTime) { this.usedTime = usedTime; }

    public LocalDateTime getExpiryTime() { return expiryTime; }
    public void setExpiryTime(LocalDateTime expiryTime) { this.expiryTime = expiryTime; }

    public String getVerifiedBy() { return verifiedBy; }
    public void setVerifiedBy(String verifiedBy) { this.verifiedBy = verifiedBy; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
