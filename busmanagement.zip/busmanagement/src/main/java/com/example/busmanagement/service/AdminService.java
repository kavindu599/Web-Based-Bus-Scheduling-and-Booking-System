package com.example.busmanagement.service;

import com.example.busmanagement.entity.Issue;
import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.entity.Trip;
import com.example.busmanagement.repository.IssueRepository;
import com.example.busmanagement.repository.PassengerRepository;
import com.example.busmanagement.repository.TripRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class AdminService {

    @Autowired
    private TripRepository tripRepository;

    @Autowired
    private PassengerRepository passengerRepository;

    @Autowired
    private IssueRepository issueRepository;

    // ===== TRIPS MANAGEMENT =====

    public List<Trip> getAllTrips() {
        return tripRepository.findAll();
    }

    public Trip saveTrip(Trip trip) {
        return tripRepository.save(trip);
    }

    public Trip getTripById(Long id) {
        Optional<Trip> trip = tripRepository.findById(id);
        return trip.orElse(null);
    }

    public Trip updateTrip(Trip trip) {
        if (trip.getId() == null || !tripRepository.existsById(trip.getId())) {
            throw new RuntimeException("Trip not found with id: " + trip.getId());
        }
        return tripRepository.save(trip);
    }

    public void deleteTrip(Long id) {
        if (!tripRepository.existsById(id)) {
            throw new RuntimeException("Trip not found with id: " + id);
        }
        tripRepository.deleteById(id);
    }

    // ===== PASSENGERS MANAGEMENT =====

    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }

    public Passenger savePassenger(Passenger passenger) {
        return passengerRepository.save(passenger);
    }

    public Passenger getPassengerById(Long id) {
        Optional<Passenger> passenger = passengerRepository.findById(id);
        return passenger.orElse(null);
    }

    public Passenger updatePassenger(Passenger passenger) {
        if (passenger.getId() == null || !passengerRepository.existsById(passenger.getId())) {
            throw new RuntimeException("Passenger not found with id: " + passenger.getId());
        }
        return passengerRepository.save(passenger);
    }

    public void deletePassenger(Long id) {
        if (!passengerRepository.existsById(id)) {
            throw new RuntimeException("Passenger not found with id: " + id);
        }
        passengerRepository.deleteById(id);
    }

    // ===== ISSUES MANAGEMENT =====

    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    public List<Issue> getIssuesFiltered(Long driverId, String status, String issueType, Long tripId) {
        // Apply ALL provided filters (AND logic). Simple and effective for admin list sizes.
        List<Issue> all = issueRepository.findAll();
        return all.stream()
                .filter(i -> driverId == null || driverId.equals(i.getDriverId()))
                .filter(i -> tripId == null || tripId.equals(i.getTripId()))
                .filter(i -> status == null || status.isBlank() || status.equals(i.getStatus()))
                .filter(i -> issueType == null || issueType.isBlank() || issueType.equalsIgnoreCase(i.getIssueType()))
                .toList();
    }

    public Issue getIssueById(Long id) {
        Optional<Issue> issue = issueRepository.findById(id);
        return issue.orElse(null);
    }

    public Issue updateIssue(Issue issue) {
        if (issue.getId() == null || !issueRepository.existsById(issue.getId())) {
            throw new RuntimeException("Issue not found with id: " + issue.getId());
        }

        // Update the updatedAt timestamp
        issue.setUpdatedAt(LocalDateTime.now());

        return issueRepository.save(issue);
    }

    public void deleteIssue(Long id) {
        if (!issueRepository.existsById(id)) {
            throw new RuntimeException("Issue not found with id: " + id);
        }
        issueRepository.deleteById(id);
    }

    public void resolveIssue(Long id) {
        Issue issue = getIssueById(id);
        if (issue == null) {
            throw new RuntimeException("Issue not found with id: " + id);
        }

        issue.setStatus("RESOLVED");
        issue.setUpdatedAt(LocalDateTime.now());
        issueRepository.save(issue);
    }

    public Issue updateIssueStatus(Long id, String status) {
        Issue issue = getIssueById(id);
        if (issue == null) {
            throw new RuntimeException("Issue not found with id: " + id);
        }
        issue.setStatus(status);
        issue.setUpdatedAt(LocalDateTime.now());
        return issueRepository.save(issue);
    }

    public Issue updateIssueFeedback(Long id, String feedback) {
        Issue issue = getIssueById(id);
        if (issue == null) {
            throw new RuntimeException("Issue not found with id: " + id);
        }
        issue.setFeedback(feedback);
        issue.setUpdatedAt(LocalDateTime.now());
        return issueRepository.save(issue);
    }

    // ===== ADDITIONAL UTILITY METHODS =====

    /**
     * Get all available trips for dropdown selection
     */
    public List<Trip> getAvailableTrips() {
        return tripRepository.findAll();
    }

    /**
     * Get all available drivers for dropdown selection
     */
    public List<Object[]> getAvailableDrivers() {
        // This would typically query a Driver entity or User entity with DRIVER role
        // For now, returning a simple list structure
        return List.of(
            new Object[]{1L, "John Driver"},
            new Object[]{2L, "Jane Driver"},
            new Object[]{3L, "Bob Driver"}
        );
    }
}
