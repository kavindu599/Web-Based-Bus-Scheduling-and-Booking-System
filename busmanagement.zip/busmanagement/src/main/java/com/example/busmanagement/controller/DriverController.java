package com.example.busmanagement.controller;

import com.example.busmanagement.entity.Issue;
import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.entity.Trip;
import com.example.busmanagement.service.IssueService;
import com.example.busmanagement.service.TripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/driver")
public class DriverController {

    @Autowired
    private TripService tripService;

    @Autowired
    private IssueService issueService;

    @GetMapping("/trips")
    public String listTrips(Model model) {
        model.addAttribute("trips", tripService.getTripsForCurrentDriver());
        model.addAttribute("pageTitle", "My Trips");
        return "driver/trips";
    }

    @GetMapping("/trip/{id}")
    public String viewTrip(@PathVariable Long id, Model model) {
        Trip trip = tripService.getTripById(id);
        if (trip == null) {
            return "redirect:/driver/trips";
        }

        model.addAttribute("trip", trip);
        model.addAttribute("passengers", tripService.getPassengersForTrip(id));
        model.addAttribute("pageTitle", "Trip Details - " + trip.getRoute());
        return "driver/trip-details";
    }

    @GetMapping("/report-issue")
    public String showReportIssueForm(Model model) {
        model.addAttribute("issue", new Issue());
        model.addAttribute("trips", tripService.getTripsForCurrentDriver());
        model.addAttribute("pageTitle", "Report Issue");
        return "driver/report-issue";
    }

    @PostMapping("/report-issue")
    public String submitIssue(@ModelAttribute Issue issue, RedirectAttributes redirectAttributes) {
        try {
            issueService.reportIssue(issue);
            redirectAttributes.addFlashAttribute("success", "Issue reported successfully!");
            return "redirect:/driver/issues";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to report issue. Please try again.");
            return "redirect:/driver/report-issue";
        }
    }

    @GetMapping("/issues")
    public String listReportedIssues(Model model) {
        model.addAttribute("issues", issueService.getIssuesReportedByCurrentDriver());
        model.addAttribute("pageTitle", "My Reported Issues");
        return "driver/issues";
    }

    @GetMapping("/trip/{tripId}/passengers")
    @ResponseBody
    public java.util.List<Passenger> getTripPassengers(@PathVariable Long tripId) {
        return tripService.getPassengersForTrip(tripId);
    }

    @PostMapping("/trip/{tripId}/passengers")
    @ResponseBody
    public Passenger addPassenger(@PathVariable Long tripId, @RequestBody Passenger passenger) {
        passenger.setTripId(tripId);
        return tripService.addPassengerToTrip(passenger);
    }

    @PostMapping("/passenger/{passengerId}/board")
    @ResponseBody
    public Passenger markPassengerBoarded(@PathVariable Long passengerId) {
        return tripService.markPassengerBoarded(passengerId);
    }
}
