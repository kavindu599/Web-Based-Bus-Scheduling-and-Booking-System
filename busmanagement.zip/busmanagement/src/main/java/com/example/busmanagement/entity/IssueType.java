package com.example.busmanagement.entity;

public enum IssueType {
    MECHANICAL_PROBLEM,
    DELAY,
    PASSENGER_INCIDENT,
    ROAD_CONDITION,
    ACCIDENT,
    OTHER
}
