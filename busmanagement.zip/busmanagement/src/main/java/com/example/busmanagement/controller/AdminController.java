package com.example.busmanagement.controller;

import com.example.busmanagement.entity.Issue;
import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.entity.Trip;
import com.example.busmanagement.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // ===== DASHBOARD =====

    @GetMapping({"", "/"})
    public String adminDashboard(Model model) {
        model.addAttribute("totalTrips", adminService.getAllTrips().size());
        model.addAttribute("totalPassengers", adminService.getAllPassengers().size());
        model.addAttribute("totalIssues", adminService.getAllIssues().size());
        model.addAttribute("pageTitle", "Admin Dashboard");
        return "admin/dashboard";
    }

    // ===== TRIPS MANAGEMENT =====

    @GetMapping("/trips")
    public String manageTrips(Model model) {
        model.addAttribute("trips", adminService.getAllTrips());
        model.addAttribute("pageTitle", "Manage Trips");
        return "admin/trips";
    }

    @GetMapping("/trips/new")
    public String showCreateTripForm(Model model) {
        model.addAttribute("trip", new Trip());
        model.addAttribute("isEdit", false);
        model.addAttribute("pageTitle", "Create New Trip");
        return "admin/trip-form";
    }

    @PostMapping("/trips")
    public String saveTrip(@ModelAttribute Trip trip, RedirectAttributes redirectAttributes) {
        try {
            adminService.saveTrip(trip);
            redirectAttributes.addFlashAttribute("success", "Trip created successfully!");
            return "redirect:/admin/trips";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to create trip. Please try again.");
            return "redirect:/admin/trips/new";
        }
    }

    @GetMapping("/trips/{id}/edit")
    public String showEditTripForm(@PathVariable Long id, Model model) {
        Trip trip = adminService.getTripById(id);
        if (trip == null) {
            return "redirect:/admin/trips";
        }

        model.addAttribute("trip", trip);
        model.addAttribute("isEdit", true);
        model.addAttribute("pageTitle", "Edit Trip");
        return "admin/trip-form";
    }

    @PutMapping("/trips/{id}")
    public String updateTrip(@PathVariable Long id, @ModelAttribute Trip trip,
                           RedirectAttributes redirectAttributes) {
        try {
            trip.setId(id);
            adminService.updateTrip(trip);
            redirectAttributes.addFlashAttribute("success", "Trip updated successfully!");
            return "redirect:/admin/trips";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update trip. Please try again.");
            return "redirect:/admin/trips/" + id + "/edit";
        }
    }

    @DeleteMapping("/trips/{id}")
    public String deleteTrip(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteTrip(id);
            redirectAttributes.addFlashAttribute("success", "Trip deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete trip. Please try again.");
        }
        return "redirect:/admin/trips";
    }

    // ===== PASSENGERS MANAGEMENT =====

    @GetMapping("/passengers")
    public String managePassengers(Model model) {
        model.addAttribute("passengers", adminService.getAllPassengers());
        model.addAttribute("pageTitle", "Manage Passengers");
        return "admin/passengers";
    }

    @GetMapping("/passengers/new")
    public String showCreatePassengerForm(Model model) {
        model.addAttribute("passenger", new Passenger());
        model.addAttribute("trips", adminService.getAllTrips());
        model.addAttribute("isEdit", false);
        model.addAttribute("pageTitle", "Add New Passenger");
        return "admin/passenger-form";
    }

    @PostMapping("/passengers")
    public String savePassenger(@ModelAttribute Passenger passenger, RedirectAttributes redirectAttributes) {
        try {
            adminService.savePassenger(passenger);
            redirectAttributes.addFlashAttribute("success", "Passenger added successfully!");
            return "redirect:/admin/passengers";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to add passenger. Please try again.");
            return "redirect:/admin/passengers/new";
        }
    }

    @GetMapping("/passengers/{id}/edit")
    public String showEditPassengerForm(@PathVariable Long id, Model model) {
        Passenger passenger = adminService.getPassengerById(id);
        if (passenger == null) {
            return "redirect:/admin/passengers";
        }

        model.addAttribute("passenger", passenger);
        model.addAttribute("trips", adminService.getAllTrips());
        model.addAttribute("isEdit", true);
        model.addAttribute("pageTitle", "Edit Passenger");
        return "admin/passenger-form";
    }

    @PutMapping("/passengers/{id}")
    public String updatePassenger(@PathVariable Long id, @ModelAttribute Passenger passenger,
                                RedirectAttributes redirectAttributes) {
        try {
            passenger.setId(id);
            adminService.updatePassenger(passenger);
            redirectAttributes.addFlashAttribute("success", "Passenger updated successfully!");
            return "redirect:/admin/passengers";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update passenger. Please try again.");
            return "redirect:/admin/passengers/" + id + "/edit";
        }
    }

    @DeleteMapping("/passengers/{id}")
    public String deletePassenger(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.deletePassenger(id);
            redirectAttributes.addFlashAttribute("success", "Passenger deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete passenger. Please try again.");
        }
        return "redirect:/admin/passengers";
    }

    // ===== ISSUES MANAGEMENT =====

    @GetMapping("/issues")
    public String manageIssues(
            @RequestParam(value = "driverId", required = false) Long driverId,
            @RequestParam(value = "tripId", required = false) Long tripId,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "issueType", required = false) String issueType,
            Model model) {

        model.addAttribute("issues", adminService.getIssuesFiltered(driverId, status, issueType, tripId));
        model.addAttribute("pageTitle", "Manage Issues");

        // Echo current filters back to the view
        model.addAttribute("filterDriverId", driverId);
        model.addAttribute("filterTripId", tripId);
        model.addAttribute("filterStatus", status);
        model.addAttribute("filterIssueType", issueType);

        // Provide driver list for dropdown (id, name)
        model.addAttribute("drivers", adminService.getAvailableDrivers());

        return "admin/issues";
    }

    @GetMapping("/issues/{id}/edit")
    public String showEditIssueForm(@PathVariable Long id, Model model) {
        Issue issue = adminService.getIssueById(id);
        if (issue == null) {
            return "redirect:/admin/issues";
        }

        model.addAttribute("issue", issue);
        model.addAttribute("isEdit", true);
        model.addAttribute("pageTitle", "Edit Issue");
        return "admin/issue-form";
    }

    @PutMapping("/issues/{id}")
    public String updateIssue(@PathVariable Long id, @ModelAttribute Issue issue,
                            RedirectAttributes redirectAttributes) {
        try {
            issue.setId(id);
            adminService.updateIssue(issue);
            redirectAttributes.addFlashAttribute("success", "Issue updated successfully!");
            return "redirect:/admin/issues";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update issue. Please try again.");
            return "redirect:/admin/issues/" + id + "/edit";
        }
    }

    @DeleteMapping("/issues/{id}")
    public String deleteIssue(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteIssue(id);
            redirectAttributes.addFlashAttribute("success", "Issue deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete issue. Please try again.");
        }
        return "redirect:/admin/issues";
    }

    // POST-based delete fallback to avoid 405 when HiddenHttpMethodFilter is not applied
    @PostMapping("/issues/{id}/delete")
    public String deleteIssuePost(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.deleteIssue(id);
            redirectAttributes.addFlashAttribute("success", "Issue deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete issue. Please try again.");
        }
        return "redirect:/admin/issues";
    }

    @PostMapping("/issues/{id}/resolve")
    public String resolveIssue(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            adminService.resolveIssue(id);
            redirectAttributes.addFlashAttribute("success", "Issue marked as resolved!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to resolve issue. Please try again.");
        }
        return "redirect:/admin/issues";
    }

    // Update issue status (AJAX)
    @PostMapping("/issues/{id}/status")
    @ResponseBody
    public String updateIssueStatus(@PathVariable Long id, @RequestParam("status") String status) {
        adminService.updateIssueStatus(id, status);
        return "OK";
    }

    @PostMapping("/issues/{id}/feedback")
    public String updateIssueFeedback(@PathVariable Long id,
                                      @RequestParam("feedback") String feedback,
                                      RedirectAttributes redirectAttributes) {
        try {
            adminService.updateIssueFeedback(id, feedback);
            redirectAttributes.addFlashAttribute("success", "Feedback saved successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to save feedback.");
        }
        return "redirect:/admin/issues";
    }
}
