package com.example.busmanagement.repository;

import com.example.busmanagement.entity.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {
    
    List<Trip> findByDriverId(Long driverId);
    
    List<Trip> findByDriverIdAndTripDate(Long driverId, LocalDate tripDate);
}