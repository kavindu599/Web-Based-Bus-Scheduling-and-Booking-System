package com.example.busmanagement.service;

import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PassengerService {
    
    @Autowired
    private PassengerRepository passengerRepository;
    
    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }
    
    public Optional<Passenger> getPassengerById(Long passengerId) {
        return passengerRepository.findById(passengerId);
    }
    
    public Passenger createPassenger(Passenger passenger) {
        return passengerRepository.save(passenger);
    }
    
    public Passenger updatePassenger(Long passengerId, Passenger passengerDetails) {
        Optional<Passenger> passengerOpt = passengerRepository.findById(passengerId);
        
        if (passengerOpt.isPresent()) {
            Passenger passenger = passengerOpt.get();
            if (passengerDetails.getName() != null) {
                passenger.setName(passengerDetails.getName());
            }
            if (passengerDetails.getTicketNumber() != null) {
                passenger.setTicketNumber(passengerDetails.getTicketNumber());
            }
            if (passengerDetails.getSeatNumber() != null) {
                passenger.setSeatNumber(passengerDetails.getSeatNumber());
            }
            if (passengerDetails.getContactNumber() != null) {
                passenger.setContactNumber(passengerDetails.getContactNumber());
            }
            return passengerRepository.save(passenger);
        }
        
        return null;
    }
    
    public void deletePassenger(Long passengerId) {
        passengerRepository.deleteById(passengerId);
    }
}
