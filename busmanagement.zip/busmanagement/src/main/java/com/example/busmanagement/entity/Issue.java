package com.example.busmanagement.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "issues")
public class Issue {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "issue_id")
    private Long issueId;
    
    @Column(name = "trip_id", nullable = false)
    private Long tripId;
    
    @Column(name = "driver_id", nullable = false)
    private Long driverId;
    
    @Column(name = "issue_type", nullable = false, length = 50)
    private String issueType;
    
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;
    
    @Column(nullable = false, length = 100)
    private String location;
    
    @Column(name = "reported_at", nullable = false)
    private LocalDateTime reportedAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @Column(nullable = false, length = 20)
    private String status;

    @Column(columnDefinition = "TEXT")
    private String feedback;
    
    // Constructors
    public Issue() {
        this.reportedAt = LocalDateTime.now();
        this.status = "Pending";
    }
    
    public Issue(Long tripId, Long driverId, String issueType, String description, String location) {
        this.tripId = tripId;
        this.driverId = driverId;
        this.issueType = issueType;
        this.description = description;
        this.location = location;
        this.reportedAt = LocalDateTime.now();
        this.status = "Pending";
    }
    
    // Getters and Setters
    public Long getIssueId() { return issueId; }
    public void setIssueId(Long issueId) { this.issueId = issueId; }
    
    public Long getTripId() { return tripId; }
    public void setTripId(Long tripId) { this.tripId = tripId; }
    
    public Long getDriverId() { return driverId; }
    public void setDriverId(Long driverId) { this.driverId = driverId; }
    
    public String getIssueType() { return issueType; }
    public void setIssueType(String issueType) { this.issueType = issueType; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public LocalDateTime getReportedAt() { return reportedAt; }
    public void setReportedAt(LocalDateTime reportedAt) { this.reportedAt = reportedAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public void setId(Long id) {
        this.issueId = id;
    }

    public Long getId() {
        return issueId;
    }
}
