package com.example.busmanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/auth")
public class AuthController {

    @GetMapping("/login")
    public String showLoginForm() {
        return "auth/login";
    }

    @GetMapping("/register")
    public String showRegisterForm() {
        return "auth/register";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String username, @RequestParam String password,
                              RedirectAttributes redirectAttributes) {
        // TODO: Implement actual authentication logic
        if ("admin".equals(username) && "admin123".equals(password)) {
            return "redirect:/admin/trips";
        } else if ("driver".equals(username) && "driver123".equals(password)) {
            return "redirect:/driver/trips";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid username or password");
            return "redirect:/auth/login";
        }
    }

    @PostMapping("/register")
    public String processRegister(@RequestParam String username, @RequestParam String email,
                                @RequestParam String password, @RequestParam String role,
                                RedirectAttributes redirectAttributes) {
        // TODO: Implement actual registration logic
        redirectAttributes.addFlashAttribute("success", "Registration successful! Please login.");
        return "redirect:/auth/login";
    }
}
