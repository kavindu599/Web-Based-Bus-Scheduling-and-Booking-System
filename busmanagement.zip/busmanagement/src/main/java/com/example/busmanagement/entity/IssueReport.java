package com.example.busmanagement.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "issue_reports")
public class IssueReport {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;
    
    @Column(nullable = false)
    private Long scheduleId;
    
    @Column(nullable = false)
    private Long driverId;
    
    @Column(nullable = false, length = 100)
    private String driverName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueType issueType;
    
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;
    
    @Column(nullable = false, length = 200)
    private String location;
    
    @Column(nullable = false)
    private LocalDateTime reportedAt;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueStatus status;
    
    // Constructors
    public IssueReport() {
        this.reportedAt = LocalDateTime.now();
        this.status = IssueStatus.OPEN;
    }
    
    public IssueReport(Long scheduleId, Long driverId, String driverName, 
                       IssueType issueType, String description, String location) {
        this.scheduleId = scheduleId;
        this.driverId = driverId;
        this.driverName = driverName;
        this.issueType = issueType;
        this.description = description;
        this.location = location;
        this.reportedAt = LocalDateTime.now();
        this.status = IssueStatus.OPEN;
    }
    
    // Getters and Setters
    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }
    
    public Long getScheduleId() { return scheduleId; }
    public void setScheduleId(Long scheduleId) { this.scheduleId = scheduleId; }
    
    public Long getDriverId() { return driverId; }
    public void setDriverId(Long driverId) { this.driverId = driverId; }
    
    public String getDriverName() { return driverName; }
    public void setDriverName(String driverName) { this.driverName = driverName; }
    
    public IssueType getIssueType() { return issueType; }
    public void setIssueType(IssueType issueType) { this.issueType = issueType; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public LocalDateTime getReportedAt() { return reportedAt; }
    public void setReportedAt(LocalDateTime reportedAt) { this.reportedAt = reportedAt; }
    
    public IssueStatus getStatus() { return status; }
    public void setStatus(IssueStatus status) { this.status = status; }
}