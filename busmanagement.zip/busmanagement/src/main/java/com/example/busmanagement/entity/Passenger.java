package com.example.busmanagement.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "passengers")
public class Passenger {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "passenger_id")
    private Long passengerId;
    
    @Column(name = "trip_id", nullable = false)
    private Long tripId;
    
    @Column(nullable = false, length = 100)
    private String name;
    
    @Column(nullable = false, length = 50)
    private String ticketNumber;
    
    @Column(length = 20)
    private String seatNumber;
    
    @Column(length = 20)
    private String contactNumber;
    
    @Column(nullable = false, length = 20)
    private String status;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trip_id", insertable = false, updatable = false)
    @JsonBackReference
    private Trip trip;
    
    // Constructors
    public Passenger() {
        this.status = "ACTIVE";
    }
    
    public Passenger(Long tripId, String name, String ticketNumber) {
        this.tripId = tripId;
        this.name = name;
        this.ticketNumber = ticketNumber;
        this.status = "ACTIVE";
    }
    
    // Getters and Setters
    public Long getPassengerId() { return passengerId; }
    public void setPassengerId(Long passengerId) { this.passengerId = passengerId; }
    
    public Long getTripId() { return tripId; }
    public void setTripId(Long tripId) { this.tripId = tripId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getTicketNumber() { return ticketNumber; }
    public void setTicketNumber(String ticketNumber) { this.ticketNumber = ticketNumber; }
    
    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Trip getTrip() { return trip; }
    public void setTrip(Trip trip) { this.trip = trip; }

    public void setId(Long id) {
        this.passengerId = id;
    }

    public Long getId() {
        return passengerId;
    }
}