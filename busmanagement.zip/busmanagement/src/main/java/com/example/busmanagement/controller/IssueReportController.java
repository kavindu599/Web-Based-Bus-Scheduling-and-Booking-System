package com.example.busmanagement.controller;

import com.example.busmanagement.entity.IssueReport;
import com.example.busmanagement.service.IssueReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/issues")
@CrossOrigin(origins = "*")
public class IssueReportController {
    
    @Autowired
    private IssueReportService issueReportService;
    
    @GetMapping
    public ResponseEntity<List<IssueReport>> getAllIssueReports() {
        List<IssueReport> reports = issueReportService.getAllIssueReports();
        return ResponseEntity.ok(reports);
    }
    
    @GetMapping("/{reportId}")
    public ResponseEntity<IssueReport> getIssueReportById(@PathVariable Long reportId) {
        Optional<IssueReport> report = issueReportService.getIssueReportById(reportId);
        return report.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/driver/{driverId}")
    public ResponseEntity<List<IssueReport>> getIssueReportsByDriverId(@PathVariable Long driverId) {
        List<IssueReport> reports = issueReportService.getIssueReportsByDriverId(driverId);
        return ResponseEntity.ok(reports);
    }
    
    @GetMapping("/trip/{scheduleId}")
    public ResponseEntity<List<IssueReport>> getIssueReportsByScheduleId(@PathVariable Long scheduleId) {
        List<IssueReport> reports = issueReportService.getIssueReportsByScheduleId(scheduleId);
        return ResponseEntity.ok(reports);
    }
    
    @PostMapping
    public ResponseEntity<IssueReport> createIssueReport(@RequestBody IssueReport issueReport) {
        IssueReport createdReport = issueReportService.createIssueReport(issueReport);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReport);
    }
    
    @PutMapping("/{reportId}")
    public ResponseEntity<IssueReport> updateIssueReport(@PathVariable Long reportId, @RequestBody IssueReport issueReport) {
        IssueReport updatedReport = issueReportService.updateIssueReport(reportId, issueReport);
        if (updatedReport != null) {
            return ResponseEntity.ok(updatedReport);
        }
        return ResponseEntity.notFound().build();
    }
    
    @DeleteMapping("/{reportId}")
    public ResponseEntity<Void> deleteIssueReport(@PathVariable Long reportId) {
        issueReportService.deleteIssueReport(reportId);
        return ResponseEntity.noContent().build();
    }
}