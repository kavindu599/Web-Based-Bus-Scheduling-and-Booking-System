package com.example.busmanagement.repository;

import com.example.busmanagement.entity.IssueReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface IssueReportRepository extends JpaRepository<IssueReport, Long> {
    
    List<IssueReport> findByDriverId(Long driverId);
    
    List<IssueReport> findByScheduleId(Long scheduleId);
}