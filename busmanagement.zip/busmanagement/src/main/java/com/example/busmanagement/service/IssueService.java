package com.example.busmanagement.service;

import com.example.busmanagement.entity.Issue;
import com.example.busmanagement.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    public Issue getIssueById(Long id) {
        Optional<Issue> issue = issueRepository.findById(id);
        return issue.orElse(null);
    }

    public Issue reportIssue(Issue issue) {
        // TODO: Get current driver ID from Spring Security context
        Long currentDriverId = 1L; // Placeholder - replace with actual security context
        issue.setDriverId(currentDriverId);
        issue.setReportedAt(LocalDateTime.now());
        issue.setStatus("PENDING");
        return issueRepository.save(issue);
    }

    public Issue updateIssue(Issue issue) {
        if (issue.getIssueId() == null || !issueRepository.existsById(issue.getIssueId())) {
            throw new RuntimeException("Issue not found with id: " + issue.getIssueId());
        }

        issue.setUpdatedAt(LocalDateTime.now());
        return issueRepository.save(issue);
    }

    public void deleteIssue(Long id) {
        if (!issueRepository.existsById(id)) {
            throw new RuntimeException("Issue not found with id: " + id);
        }
        issueRepository.deleteById(id);
    }

    public List<Issue> getIssuesReportedByCurrentDriver() {
        // TODO: Get current driver ID from Spring Security context
        Long currentDriverId = 1L; // Placeholder - replace with actual security context
        return issueRepository.findByDriverId(currentDriverId);
    }

    public List<Issue> getIssuesByTripId(Long tripId) {
        return issueRepository.findByTripId(tripId);
    }

    public Issue resolveIssue(Long id) {
        Issue issue = getIssueById(id);
        if (issue == null) {
            throw new RuntimeException("Issue not found with id: " + id);
        }

        issue.setStatus("RESOLVED");
        issue.setUpdatedAt(LocalDateTime.now());
        return issueRepository.save(issue);
    }

    public List<Issue> getIssuesByStatus(String status) {
        return issueRepository.findByStatus(status);
    }

    public List<Issue> getIssuesByType(String issueType) {
        return issueRepository.findByIssueType(issueType);
    }

    public List<Issue> getIssuesByDriverId(Long driverId) {
        return issueRepository.findByDriverId(driverId);
    }
}
