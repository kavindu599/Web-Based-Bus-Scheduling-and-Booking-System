package com.example.busmanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    
    @GetMapping("/")
    public String home() {
        return "driver-dashboard";
    }
    
    @GetMapping("/dashboard")
    public String dashboard() {
        return "driver-dashboard";
    }
    
    @GetMapping("/driver-dashboard")
    public String driverDashboard() {
        return "driver-dashboard";
    }
    
    
    @GetMapping("/reports")
    public String reports() {
        return "reports";
    }
}
