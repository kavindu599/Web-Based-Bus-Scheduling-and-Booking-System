package com.example.busmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusmanagementApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(BusmanagementApplication.class, args);
        System.out.println("\n==============================================");
        System.out.println("Bus Management System Started Successfully!");
        System.out.println("API Base URL: http://localhost:8080");
        System.out.println("MySQL Database: busdb");
        System.out.println("==============================================\n");
    }
}