package com.example.busmanagement.service;

import com.example.busmanagement.entity.IssueReport;
import com.example.busmanagement.repository.IssueReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class IssueReportService {
    
    @Autowired
    private IssueReportRepository issueReportRepository;
    
    public List<IssueReport> getAllIssueReports() {
        return issueReportRepository.findAll();
    }
    
    public Optional<IssueReport> getIssueReportById(Long reportId) {
        return issueReportRepository.findById(reportId);
    }
    
    public List<IssueReport> getIssueReportsByDriverId(Long driverId) {
        return issueReportRepository.findByDriverId(driverId);
    }
    
    public List<IssueReport> getIssueReportsByScheduleId(Long scheduleId) {
        return issueReportRepository.findByScheduleId(scheduleId);
    }
    
    public IssueReport createIssueReport(IssueReport issueReport) {
        return issueReportRepository.save(issueReport);
    }
    
    public IssueReport updateIssueReport(Long reportId, IssueReport reportDetails) {
        Optional<IssueReport> reportOpt = issueReportRepository.findById(reportId);
        
        if (reportOpt.isPresent()) {
            IssueReport report = reportOpt.get();
            if (reportDetails.getIssueType() != null) {
                report.setIssueType(reportDetails.getIssueType());
            }
            if (reportDetails.getDescription() != null) {
                report.setDescription(reportDetails.getDescription());
            }
            if (reportDetails.getLocation() != null) {
                report.setLocation(reportDetails.getLocation());
            }
            if (reportDetails.getStatus() != null) {
                report.setStatus(reportDetails.getStatus());
            }
            return issueReportRepository.save(report);
        }
        
        return null;
    }
    
    public void deleteIssueReport(Long reportId) {
        issueReportRepository.deleteById(reportId);
    }
}
