package com.example.busmanagement.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "trips")
public class Trip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "trip_id")
    private Long tripId;

    @Column(name = "driver_id", nullable = false)
    private Long driverId;

    @Column(name = "route_id", nullable = false)
    private Long routeId;

    @Column(name = "schedule_id", nullable = false)
    private Long scheduleId;

    @Column(name = "trip_date", nullable = false)
    private LocalDate tripDate;

    @OneToMany(mappedBy = "trip", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<Passenger> passengers = new ArrayList<>();

    // Constructors
    public Trip() {}

    public Trip(Long driverId, Long routeId, Long scheduleId, LocalDate tripDate) {
        this.driverId = driverId;
        this.routeId = routeId;
        this.scheduleId = scheduleId;
        this.tripDate = tripDate;
    }

    // Getters and Setters
    public Long getTripId() { return tripId; }
    public void setTripId(Long tripId) { this.tripId = tripId; }

    public Long getDriverId() { return driverId; }
    public void setDriverId(Long driverId) { this.driverId = driverId; }

    public Long getRouteId() { return routeId; }
    public void setRouteId(Long routeId) { this.routeId = routeId; }

    public Long getScheduleId() { return scheduleId; }
    public void setScheduleId(Long scheduleId) { this.scheduleId = scheduleId; }

    public LocalDate getTripDate() { return tripDate; }
    public void setTripDate(LocalDate tripDate) { this.tripDate = tripDate; }

    public List<Passenger> getPassengers() { return passengers; }
    public void setPassengers(List<Passenger> passengers) { this.passengers = passengers; }

    // Helper methods for templates (these return placeholder values)
    public String getRoute() {
        return "Route " + routeId; // Placeholder - would need actual Route entity
    }

    public String getDriverName() {
        return "Driver " + driverId; // Placeholder - would need actual Driver entity
    }

    public String getSchedule() {
        return "Schedule " + scheduleId; // Placeholder - would need actual Schedule entity
    }

    public String getStatus() {
        return "SCHEDULED"; // Placeholder - would need actual status field
    }

    public Integer getPassengerCount() {
        return passengers != null ? passengers.size() : 0;
    }

    public void setId(Long id) {
        this.tripId = id;
    }

    public Long getId() {
        return tripId;
    }
}