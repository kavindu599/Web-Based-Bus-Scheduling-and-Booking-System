package com.example.busmanagement.controller;

import com.example.busmanagement.entity.Issue;
import com.example.busmanagement.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
public class IssueController {
    
    @Autowired
    private IssueRepository issueRepository;
    
    // GET /issues → List all issues
    @GetMapping("/issues")
    public ResponseEntity<List<Issue>> getAllIssues() {
        List<Issue> issues = issueRepository.findAll();
        return ResponseEntity.ok(issues);
    }
    
    // POST /issues → Report an issue
    @PostMapping("/issues")
    public ResponseEntity<Issue> reportIssue(@RequestBody Issue issue) {
        Issue savedIssue = issueRepository.save(issue);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedIssue);
    }
    
    // PUT /issues/{id} → Update issue (status, description)
    @PutMapping("/issues/{id}")
    public ResponseEntity<Issue> updateIssue(@PathVariable Long id, @RequestBody Issue issueDetails) {
        Optional<Issue> optionalIssue = issueRepository.findById(id);
        if (optionalIssue.isPresent()) {
            Issue issue = optionalIssue.get();
            issue.setStatus(issueDetails.getStatus());
            issue.setDescription(issueDetails.getDescription());
            if (issueDetails.getIssueType() != null) {
                issue.setIssueType(issueDetails.getIssueType());
            }
            if (issueDetails.getLocation() != null) {
                issue.setLocation(issueDetails.getLocation());
            }
            Issue updatedIssue = issueRepository.save(issue);
            return ResponseEntity.ok(updatedIssue);
        }
        return ResponseEntity.notFound().build();
    }
    
    // DELETE /issues/{id} → Delete issue
    @DeleteMapping("/issues/{id}")
    public ResponseEntity<Void> deleteIssue(@PathVariable Long id) {
        if (issueRepository.existsById(id)) {
            issueRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
