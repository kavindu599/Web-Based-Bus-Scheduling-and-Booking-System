package com.example.busmanagement.config;

import com.example.busmanagement.entity.Trip;
import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.entity.Issue;
import com.example.busmanagement.repository.TripRepository;
import com.example.busmanagement.repository.PassengerRepository;
import com.example.busmanagement.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private TripRepository tripRepository;
    
    @Autowired
    private PassengerRepository passengerRepository;
    
    @Autowired
    private IssueRepository issueRepository;
    
    @Override
    public void run(String... args) throws Exception {
        
        // Create sample trips
        Trip trip1 = new Trip(1L, 101L, 1001L, LocalDate.now());
        Trip trip2 = new Trip(1L, 102L, 1002L, LocalDate.now().plusDays(1));
        Trip trip3 = new Trip(2L, 103L, 1003L, LocalDate.now());
        
        tripRepository.save(trip1);
        tripRepository.save(trip2);
        tripRepository.save(trip3);
        
        // Create sample passengers
        Passenger p1 = new Passenger(trip1.getTripId(), "Alice Smith", "TKT001");
        Passenger p2 = new Passenger(trip1.getTripId(), "Bob Johnson", "TKT002");
        Passenger p3 = new Passenger(trip2.getTripId(), "Carol Williams", "TKT003");
        Passenger p4 = new Passenger(trip2.getTripId(), "David Brown", "TKT004");
        Passenger p5 = new Passenger(trip3.getTripId(), "Eva Davis", "TKT005");
        
        passengerRepository.save(p1);
        passengerRepository.save(p2);
        passengerRepository.save(p3);
        passengerRepository.save(p4);
        passengerRepository.save(p5);
        
        // Create sample issues
        Issue issue1 = new Issue(trip1.getTripId(), 1L, "Mechanical", "Engine overheating", "Highway Mile 25");
        Issue issue2 = new Issue(trip2.getTripId(), 1L, "Delay", "Traffic jam due to accident", "Main Street Junction");
        Issue issue3 = new Issue(trip3.getTripId(), 2L, "Passenger", "Passenger medical emergency", "Bus Stop 15");
        
        issueRepository.save(issue1);
        issueRepository.save(issue2);
        issueRepository.save(issue3);
        
        System.out.println("\n✅ Sample data initialized successfully!");
        System.out.println("✅ Database tables auto-created!");
        System.out.println("✅ 3 trips with passengers and issues loaded!\n");
    }
}
