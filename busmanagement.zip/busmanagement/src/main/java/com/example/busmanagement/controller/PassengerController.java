package com.example.busmanagement.controller;

import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class PassengerController {
    
    @Autowired
    private PassengerRepository passengerRepository;
    
    // GET /passengers?tripId={id} → Get passenger list for trip
    @GetMapping("/passengers")
    public ResponseEntity<List<Passenger>> getPassengersByTripId(@RequestParam Long tripId) {
        List<Passenger> passengers = passengerRepository.findByTripId(tripId);
        return ResponseEntity.ok(passengers);
    }
    
    // POST /passengers → Add passenger
    @PostMapping("/passengers")
    public ResponseEntity<Passenger> createPassenger(@RequestBody Passenger passenger) {
        Passenger savedPassenger = passengerRepository.save(passenger);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPassenger);
    }
}
