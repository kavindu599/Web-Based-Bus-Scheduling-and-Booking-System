package com.example.busmanagement.service;

import com.example.busmanagement.entity.Trip;
import com.example.busmanagement.entity.Passenger;
import com.example.busmanagement.repository.TripRepository;
import com.example.busmanagement.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
public class TripService {

    @Autowired
    private TripRepository tripRepository;

    @Autowired
    private PassengerRepository passengerRepository;

    public List<Trip> getAllTrips() {
        return tripRepository.findAll();
    }

    public Trip getTripById(Long id) {
        Optional<Trip> trip = tripRepository.findById(id);
        return trip.orElse(null);
    }

    public List<Trip> getTripsByDriverId(Long driverId) {
        return tripRepository.findByDriverId(driverId);
    }

    /**
     * Get trips for current driver - this would typically get the current user from security context
     * For now, assuming driverId = 1 for demo purposes
     */
    public List<Trip> getTripsForCurrentDriver() {
        // TODO: Get current driver ID from Spring Security context
        Long currentDriverId = 1L; // Placeholder - replace with actual security context
        return getTripsByDriverId(currentDriverId);
    }

    public List<Trip> getTodayTripsByDriverId(Long driverId) {
        LocalDate today = LocalDate.now();
        return tripRepository.findByDriverIdAndTripDate(driverId, today);
    }

    public List<Passenger> getPassengersForTrip(Long tripId) {
        return passengerRepository.findByTripId(tripId);
    }

    public Passenger addPassengerToTrip(Passenger passenger) {
        return passengerRepository.save(passenger);
    }

    public Trip createTrip(Trip trip) {
        return tripRepository.save(trip);
    }

    public Trip updateTrip(Long id, Trip tripDetails) {
        Optional<Trip> tripOpt = tripRepository.findById(id);

        if (tripOpt.isPresent()) {
            Trip trip = tripOpt.get();
            if (tripDetails.getRouteId() != null) {
                trip.setRouteId(tripDetails.getRouteId());
            }
            if (tripDetails.getScheduleId() != null) {
                trip.setScheduleId(tripDetails.getScheduleId());
            }
            if (tripDetails.getDriverId() != null) {
                trip.setDriverId(tripDetails.getDriverId());
            }
            if (tripDetails.getTripDate() != null) {
                trip.setTripDate(tripDetails.getTripDate());
            }
            return tripRepository.save(trip);
        }

        return null;
    }

    public void deleteTrip(Long id) {
        tripRepository.deleteById(id);
    }

    public Trip saveTrip(Trip trip) {
        return tripRepository.save(trip);
    }

    public void deleteTripById(Long id) {
        tripRepository.deleteById(id);
    }

    public Passenger markPassengerBoarded(Long passengerId) {
        Passenger passenger = passengerRepository.findById(passengerId).orElse(null);
        if (passenger != null) {
            passenger.setStatus("BOARDED");
            return passengerRepository.save(passenger);
        }
        return null;
    }
}