package com.example.busmanagement.repository;

import com.example.busmanagement.entity.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IssueRepository extends JpaRepository<Issue, Long> {
    List<Issue> findByTripId(Long tripId);
    List<Issue> findByDriverId(Long driverId);
    List<Issue> findByStatus(String status);
    List<Issue> findByIssueType(String issueType);
}
