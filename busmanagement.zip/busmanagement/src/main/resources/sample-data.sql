-- Sample Data for Trip and Manifest Management System
-- Execute these INSERT statements after the tables are created

-- Insert sample trips
INSERT INTO trips (driver_id, route_id, schedule_id, trip_date) VALUES
(1, 101, 1001, '2024-10-01'),
(1, 102, 1002, '2024-10-01'),
(1, 103, 1003, '2024-10-02'),
(2, 104, 1004, '2024-10-01'),
(2, 105, 1005, '2024-10-02'),
(3, 106, 1006, '2024-10-01');

-- Insert sample passengers
INSERT INTO passengers (trip_id, name, ticket_number) VALUES
(1, 'Alice Smith', 'TKT001'),
(1, 'Bob Johnson', 'TKT002'),
(1, 'Carol Williams', 'TKT003'),
(2, 'David Brown', 'TKT004'),
(2, 'Eva Davis', 'TKT005'),
(2, 'Frank Miller', 'TKT006'),
(3, 'Grace Wilson', 'TKT007'),
(3, 'Henry Moore', 'TKT008'),
(4, 'Iris Taylor', 'TKT009'),
(4, 'Jack Anderson', 'TKT010'),
(5, 'Karen White', 'TKT011'),
(5, 'Liam Garcia', 'TKT012'),
(6, 'Mia Rodriguez', 'TKT013'),
(6, 'Noah Martinez', 'TKT014');

-- Insert sample issues
INSERT INTO issues (trip_id, driver_id, issue_type, description, location, reported_at, status) VALUES
(1, 1, 'Mechanical', 'Engine overheating detected during trip', 'Highway Mile 25', NOW(), 'Pending'),
(2, 1, 'Delay', 'Traffic jam due to road accident causing 30min delay', 'Main Street Junction', NOW(), 'Pending'),
(3, 1, 'Passenger', 'Passenger medical emergency - elderly passenger felt dizzy', 'Bus Stop 15', NOW(), 'Resolved'),
(4, 2, 'Mechanical', 'Brake system making unusual noise', 'City Center', NOW(), 'Pending'),
(5, 2, 'Weather', 'Heavy rain causing reduced visibility and slower speeds', 'Mountain Road', NOW(), 'Pending'),
(6, 3, 'Passenger', 'Passenger complaint about air conditioning not working', 'Terminal Station', NOW(), 'In Progress');

-- Additional sample data for testing
INSERT INTO trips (driver_id, route_id, schedule_id, trip_date) VALUES
(1, 107, 1007, CURDATE()),
(2, 108, 1008, CURDATE()),
(3, 109, 1009, CURDATE());

INSERT INTO passengers (trip_id, name, ticket_number) VALUES
(7, 'Oliver Thompson', 'TKT015'),
(7, 'Sophia Clark', 'TKT016'),
(8, 'Ethan Lewis', 'TKT017'),
(8, 'Isabella Hall', 'TKT018'),
(9, 'Mason Allen', 'TKT019'),
(9, 'Charlotte Young', 'TKT020');

INSERT INTO issues (trip_id, driver_id, issue_type, description, location, reported_at, status) VALUES
(7, 1, 'Delay', 'Construction work causing detour and delays', 'Bridge Construction Zone', NOW(), 'Pending'),
(8, 2, 'Mechanical', 'Door mechanism not working properly', 'Bus Depot', NOW(), 'Pending'),
(9, 3, 'Passenger', 'Lost passenger belongings reported', 'Shopping Mall Stop', NOW(), 'In Progress');
