# Trip and Manifest Management System

## Project Overview
A complete Spring Boot backend system for **Trip and Manifest Management** with CRUD operations using MySQL. This system allows bus drivers to view assigned trips, access passenger manifests, and report issues during journeys.

## ✅ System Features

### Use Cases Implemented
- **UC-12**: View Assigned Trips - Drivers can view their assigned trips and details
- **UC-13**: Report Issues - Drivers can report issues encountered during journeys

### Backend Components
- **Spring Boot 3.x** with Maven build tool
- **MySQL Database** (busdb) with exact schema matching requirements
- **JPA/Hibernate** entities mapped to database tables
- **REST API Controllers** with exact endpoints as specified
- **Repository Layer** for data access
- **Sample Data Initialization** with SQL scripts

### Database Schema (Implemented)
```sql
CREATE TABLE trips (
    trip_id INT PRIMARY KEY AUTO_INCREMENT,
    driver_id INT NOT NULL,
    route_id INT NOT NULL,
    schedule_id INT NOT NULL,
    trip_date DATE NOT NULL
);

CREATE TABLE passengers (
    passenger_id INT PRIMARY KEY AUTO_INCREMENT,
    trip_id INT NOT NULL,
    name VARCHAR(100),
    ticket_number VARCHAR(50),
    FOREIGN KEY (trip_id) REFERENCES trips(trip_id)
);

CREATE TABLE issues (
    issue_id INT PRIMARY KEY AUTO_INCREMENT,
    trip_id INT NOT NULL,
    driver_id INT NOT NULL,
    issue_type VARCHAR(50),
    description TEXT,
    location VARCHAR(100),
    reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (trip_id) REFERENCES trips(trip_id)
);
```

### REST API Endpoints (Exact Implementation)
```
# Trips CRUD
GET    /trips           → List all trips
GET    /trips/{id}      → Get trip by ID
POST   /trips           → Create new trip
PUT    /trips/{id}      → Update trip
DELETE /trips/{id}      → Delete trip

# Passengers
GET    /passengers?tripId={id}  → Get passenger list for trip
POST   /passengers              → Add passenger

# Issues
GET    /issues          → List all issues
POST   /issues          → Report an issue
PUT    /issues/{id}     → Update issue (status, description)
DELETE /issues/{id}     → Delete issue
```

## ⚠️ Current Issue: MySQL JDBC Authentication

### Problem
The application cannot connect to MySQL via JDBC despite:
- MySQL server running on port 3306
- MySQL CLI connections working perfectly
- Correct credentials (root/root123)
- User authentication set to mysql_native_password

### Error
```
Access denied for user 'root'@'localhost' (using password: YES)
```

### Attempted Solutions
1. ✅ Created dedicated user 'busapp' with mysql_native_password
2. ✅ Changed root user to mysql_native_password
3. ✅ Tried different MySQL connector versions (8.0.33, 8.3.0)
4. ✅ Verified grants and permissions
5. ✅ Tested multiple passwords
6. ✅ Changed connection URL parameters

### Root Cause
This appears to be a MySQL 8.0 server configuration issue where JDBC connections are being rejected despite CLI connections working. This typically happens when:
- MySQL is configured with `skip-networking` or `bind-address` restrictions
- There's a firewall or security policy blocking JDBC
- MySQL authentication plugin caching issue

### Recommended Solutions

#### Option 1: Check MySQL Configuration File
Edit `my.ini` or `my.cnf` and ensure:
```ini
[mysqld]
# Comment out or remove these lines if present:
# skip-networking
# bind-address = 127.0.0.1

# Ensure these are set:
default-authentication-plugin=mysql_native_password
```

Then restart MySQL service:
```powershell
Restart-Service MySQL80
```

#### Option 2: Create User with All Hosts
```sql
CREATE USER 'busapp'@'%' IDENTIFIED WITH mysql_native_password BY 'busapp123';
GRANT ALL PRIVILEGES ON busdb.* TO 'busapp'@'%';
FLUSH PRIVILEGES;
```

Update `application.properties`:
```properties
spring.datasource.url=jdbc:mysql://127.0.0.1:3306/busdb?...
spring.datasource.username=busapp
spring.datasource.password=busapp123
```

#### Option 3: Use Different MySQL Installation
Install MySQL 8.0 fresh or use XAMPP/WAMP which have pre-configured MySQL for JDBC connections.

## 🚀 How to Run (Once MySQL is Fixed)

1. **Ensure MySQL is running** on port 3306
2. **Update credentials** in `src/main/resources/application.properties`
3. **Run the application**:
   ```bash
   ./mvnw spring-boot:run
   ```
4. **Access the application**:
   - Dashboard: http://localhost:8080
   - API: http://localhost:8080/api/trips

## 📁 Project Structure
```
busmanagement/
├── src/main/java/com/example/busmanagement/
│   ├── config/
│   │   └── DataInitializer.java
│   ├── controller/
│   │   ├── HomeController.java
│   │   ├── TripController.java
│   │   ├── PassengerController.java
│   │   └── IssueReportController.java
│   ├── entity/
│   │   ├── Trip.java
│   │   ├── Passenger.java
│   │   ├── IssueReport.java
│   │   ├── TripStatus.java
│   │   ├── IssueType.java
│   │   └── IssueStatus.java
│   ├── repository/
│   │   ├── TripRepository.java
│   │   ├── PassengerRepository.java
│   │   └── IssueReportRepository.java
│   ├── service/
│   │   ├── TripService.java
│   │   ├── PassengerService.java
│   │   └── IssueReportService.java
│   └── BusmanagementApplication.java
├── src/main/resources/
│   ├── templates/
│   │   └── driver-dashboard.html
│   ├── static/
│   │   └── styles.css
│   └── application.properties
└── pom.xml
```

## 🔧 Configuration

### Database Configuration
File: `src/main/resources/application.properties`
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/busdb?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=root123
spring.jpa.hibernate.ddl-auto=update
```

### Dependencies
- Spring Boot Starter Web
- Spring Boot Starter Data JPA
- Spring Boot Starter Thymeleaf
- MySQL Connector J 8.3.0
- Spring Boot DevTools

## 📝 Notes
- All HTML files are in `templates/` folder (Thymeleaf)
- CSS files are in `static/` folder
- No JavaScript files - pure HTML/CSS frontend
- MySQL database with auto-table creation
- Sample data loads automatically on startup
- CORS enabled for all API endpoints

## 🎯 Next Steps
1. Fix MySQL JDBC authentication issue
2. Run the application
3. Access dashboard at http://localhost:8080
4. Test API endpoints
5. View auto-created database tables in MySQL

---
**Status**: Backend complete ✅ | Frontend complete ✅ | MySQL connection issue ⚠️
